Altera Complete Design Suite Release 13.0 SP1 README.TXT
========================================================

This readme.txt file accompanies the Altera Complete Design Suite 
version 13.0 SP1.

Although we have made every effort to ensure that this version
of the Altera(R) software functions correctly, there may be
problems that we have not encountered. If you have a question or
problem that is not answered by the information provided in
this readme.txt file, please contact Altera support at 
1-800-800-EPLD or submit a service request at mysupport.altera.com.

This readme.txt file contains the following information:
*  Altera Complete Design Suite Contents--lists the set of Altera design tools.
*  Technical Documentation--directs you where to find documentation for Altera 
   design tools.
*  System Requirements--lists the system requirements.

Altera Complete Design Suite Contents
=====================================
*  Quartus II Design Software including the Qsys System Integration Tool, 
   Nios II Embedded Design Suite, and MegaCore IP Library
*  ModelSim-Altera Edition Simulation Tool
*  ModelSim-Altera Starter Edition Simulation Tool
*  DSP Builder
*  Quartus II Programmer                          
                 
You can download the software from the Altera Download Center 
on the Altera website: 
http://www.altera.com/download   

Technical Documentation
=======================
*  Quartus II Software and Device Support Release Notes version 13.0 SP1
   Provides information about new features and enhancements, known issues, 
   workarounds, device support information, memory requirements for design 
   processing, and timing/power model status. 
   This document is available on the Altera website:
   http://www.altera.com/literature/rn/rn_qts_dev_support.pdf
   
*  Nios II Embedded Design Suite Release Notes
   Provides information about new features and enhancements, errata, and 
   workarounds. This document is available on the Altera website:
   http://www.altera.com/literature/rn/rn_nios2eds.pdf
      
*  MegaCore IP Release Notes and Errata
   Provides information about new features and enhancements, errata, and 
   workarounds. This document is available on the Altera website:
   http://www.altera.com/literature/rn/rn_ip.pdf
   
*  DSP Builder Release Notes
   Provides information about new features and enhancements, errata, and 
   workarounds. This document is available on the Altera website:
   http://www.altera.com/literature/rn/rn_dsp_builder.pdf
   
*  Altera Software Installation and Licensing Manual 13.0
   Provides information about installing and licensing your Altera design
   software. This document is available on the Altera website:
   http://www.altera.com/literature/manual/quartus_install.pdf 

*  Introduction to the Quartus II Software
   Provides an introduction to using the Quartus II software. 
   This document is available on the Altera website:   
   http://www.altera.com/literature/manual/quartus2_introduction.pdf
   
*  Quartus II Handbook
   Provides detailed information about all aspects of
   the Quartus II software. This document is available on the Altera website:
   http://www.altera.com/literature/hb/qts/quartusii_handbook.pdf   

*  AN 320: OpenCore Plus Evaluation of Megafunctions
   http://www.altera.com/literature/an/an320.pdf
   
*  AN 343: OpenCore Evaluation of AMPP Megafunctions
   http://www.altera.com/literature/an/an343.pdf
   
System Requirements
===================
Operating system support
------------------------
*  Windows 7 (64 and 32 bit)
*  Windows XP SP2 (64 and 32 bit)
*  Windows XP Pro X64 Edition
*  Windows Server 2008 R2 (64 bit)
*  Red Hat Enterprise Linux 6 (64 bit)
*  Red Hat Enterprise Linux 5 (64 and 32 bit)

Note: 32-bit libraries are required for all Linux 64-bit platforms.
 
Support information for all editions of the Quartus II software 
can be found on the Altera website:
http://www.altera.com/download/os-support/oss-index.html 
                    
DSP Builder 
*  Supports MathWorks releases R2010b, R2011a, R2011b, R2012a, or R2012b. 
   
FLEXlm
   For more information on the FLEXlm license server software, refer 
   to the Altera Software Installation and Licensing manual:
   http://www.altera.com/literature/manual/quartus_install.pdf 
   
KDE or GNOME Display Manager
   *  Version included with your Linux operating system installation.
                        
